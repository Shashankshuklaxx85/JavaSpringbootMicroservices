<%@ page isELIgnored="false"  %>
<%@taglib uri="http://www.springframework.org/tags/form"  prefix="frm" %>


<h1  style="color:red;text-align:center">  Student Registration Form Page  </h1>
<frm:form   modelAttribute="stud">
   <table   border="0"  align="center"  bgcolor="yellow"  >
        <tr>
           <th> Student number :: </th>
           <th>  <frm:input type="text"  path="sno"/> </th>  
       </tr>
       <tr>
           <th> Student Name :: </th>
           <th>  <frm:input type="text"  path="sname"/> </th>  
       </tr>
       <tr>
           <th> Student Address :: </th>
           <th>  <frm:input type="text"  path="sadd"/> </th>  
       </tr>
       <tr>
           <th> Student Avg :: </th>
           <th>  <frm:input type="text"  path="avg"/> </th>  
       </tr>
       <tr>
           <th> <input type="submit" value="send"> </th>
           <th>  <input type="reset"  value="cancel"> </th>  
       </tr>
     </table>
   
  </frm:form>
