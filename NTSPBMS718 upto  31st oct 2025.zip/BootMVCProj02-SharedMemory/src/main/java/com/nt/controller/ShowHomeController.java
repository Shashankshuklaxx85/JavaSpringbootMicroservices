//ShowHomeController.java
package com.nt.controller;


import java.io.PrintWriter;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletResponse;


@Controller
public class ShowHomeController {
	
	/*	@RequestMapping("/home")
		//@RequestMapping("/")
		//@RequestMapping
		public  String  displayHomePage(Map<String,Object> map) {
			System.out.println("Shared Memory obj  class :"+map.getClass());
			 //put data in shared Memory  Model attributes
			map.put("sysDate",new Date());
			map.put("age",30);
			
			//return LVN
			return  "welcome";
		}*/
	
	/*@RequestMapping("/home")
	public  String  displayHomePage(BindingAwareModelMap map) {
		System.out.println("Shared Memory obj  class :"+map.getClass());
		 //put data in shared Memory  Model attributes
		map.put("sysDate",new Date());
		map.put("age",30);
		
		//return LVN
		return  "welcome";
	}*/
	
	/*@RequestMapping("/home")
	public  String  displayHomePage(Model model) {
		System.out.println("Shared Memory obj  class :"+model.getClass());
		 //put data in shared Memory  Model attributes
		model.addAttribute("sysDate", new Date());
		model.addAttribute("age", 30);
		//return LVN
		return  "welcome";
	}*/
	
	/*@RequestMapping("/home")
	public  String  displayHomePage(ModelMap map) {
		System.out.println("Shared Memory obj  class :"+map.getClass());
		 //put data in shared Memory  Model attributes
		map.addAttribute("sysDate", new Date());
		map.addAttribute("age", 30);
		//return LVN
		return  "welcome";
	}*/
	
	/*	//@RequestMapping("/home")
		public  Model  displayHomePage() {
			//create shared Memory
			Model model=new BindingAwareModelMap();
			model.addAttribute("sysDate",new Date());
			model.addAttribute("age",30);
			return model;
		}*/
	
	/*@RequestMapping("/home")
	public  Map<String,Object>  displayHomePage() {
		//create shared Memory
		Map<String,Object> map=new HashMap<String, Object>();
		map.put("sysDate", new Date());
		map.put("age", 30);
		return map;
	}*/
	
	/*@RequestMapping("/home")
	public  ModelAndView  displayHomePage() {
		//create shared Memory
	    ModelAndView  mav=new ModelAndView();
	    //add model attributes
		mav.addObject("sysDate", new Date());
		mav.addObject("age",30);
		//add LVN
		mav.setViewName("welcome");
		return mav;
	}
	*/
	
	/*@RequestMapping("/home")
	public  void  displayHomePage(Map<String,Object> map) {
	    //add model attributes
		map.put("sysDate", new Date());
		map.put("age",30);
		
	}*/
	
	/*@RequestMapping("/home")
	public  String  displayHomePage(Map<String,Object> map,HttpServletRequest req, 
			                                                                                                                 HttpServletResponse res) {
		System.out.println("ShowHomeController.displayHomePage()");
		System.out.println("request url ::"+req.getRequestURI());
		System.out.println("response info::"+res.getStatus());
	    //add model attributes
		map.put("sysDate", new Date());
		map.put("age",30);
		//return null
		//return "forward:report";
		return "redirect:report?sysDate="+new Date()+"&age=30";
	}
	
	@RequestMapping("/report")
	public  String  showReport(Map<String,Object> map) {
	 System.out.println("ShowHomeController.showReport()");
	 map.put("addrs", "hyd");
	  return "welcome";
	}*/
	
	/*@Autowired
	private ServletConfig cg;
	@Autowired
	private ServletContext sc;
	
	@RequestMapping("/report")
	public  String  showReport(HttpSession ses, Map<String,Object> map) {
		System.out.println("Session Id ::"+ses.getId());
		System.out.println("web application name ::"+sc.getContextPath());
		System.out.println("DS logical name ::"+cg.getServletName());
		map.put("addrs", "hyd");
		  return "welcome";
		}
	*/
	
	
		
	
	@RequestMapping("/home")
	public  void  displayHomePage(HttpServletResponse res)throws Exception {
		
	  //get PrintWriter object 
		PrintWriter  pw=res.getWriter();
		//set response content type
		res.setContentType("text/html");
		 //make the repsonse  as the downloadable file
		res.setHeader("content-disposition", "attachment;fileName=abc.html");
	   //write the output to response
		pw.println("<br> <b> Welcome to Spring  Boot MVC </b>");
	}
	
	
	
	
		
	

}
