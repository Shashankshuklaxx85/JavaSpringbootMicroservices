<%@page isELIgnored="false" %>

<h1  style="color:red;text-align:center"> Welcome Spring  Boot MVC Application</h1>

<b> Model attributes :: ${sysDate}, ${age}, ${addrs}</b>  <br>
<br> <b> Addtional req params :: ${param.sysDate}, ${param.age}    </b>
