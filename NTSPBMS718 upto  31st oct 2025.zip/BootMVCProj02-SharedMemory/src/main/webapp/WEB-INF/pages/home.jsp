<%@page isELIgnored="false" %>

<h1  style="color:red;text-align:center"> Welcome Spring  Boot MVC Application (home.jsp)</h1>

<b> Model attributes :: ${sysDate}, ${age}</b>  <br>
