package com.nt.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nt.model.Customer;
import com.nt.service.ISeasonFinderMgmtService;

@Controller
public class SeasonFinderOperationsController {
	@Autowired
	private ISeasonFinderMgmtService  seasonService;

	//@RequestMapping("/")
	@RequestMapping
	public  String showHome() {
		return "home";  //LVN
	}
	
	@RequestMapping("/season")
	public   String  showSeason(Map<String,Object> map) {
		//use service
		String msg=seasonService.findSeason();
		//keep the results in Model attribute
		map.put("resultMsg", msg);
		//passing  simple values and model attributes
				map.put("name","raja");
				map.put("age",30);
				map.put("addrs", "hyd");
		//passing  array values , collections as model attributes
			map.put("nickNames", new String[] {"raj","maharaj"});
			map.put("friends",List.of("rakesh","suresh"));
			map.put("phones",Set.of(88888888L,99999999L));
			map.put("idDetails",Map.of("aadhar",655777L,"voterId",5656565L));
		// passing  Model class obj as the Model Attributes
			   Customer cust=new Customer(1001,"raja","hyd",8999.0f);
			map.put("custData",cust);
			//passing  List of Model class objs as the Model attributes
			   Customer cust1=new Customer(1001,"rajesh","vizag",8999.0f);
			   Customer cust2=new Customer(1002,"rajesh","hyd",8999.0f);
			   Customer cust3=new Customer(1004,"suresh","delhi",8999.0f);
			   List<Customer> list=List.of(cust1,cust2,cust3);
			  // keep the data as model attributes
			   map.put("listCustData", list);
			   
		//return LVN
		return "display";
	}
	
	//@RequestMapping(value="/report1",method = RequestMethod.GET)
	@GetMapping("/report1")
	public   String  showReport1() {
		System.out.println("SeasonFinderOperationsController.showReport1() (GET)");
		return "redirect:/test-ops/report1";
	}
	
	
	/*	//@RequestMapping(value="/report1",method = RequestMethod.POST)
		@PostMapping("/report1")
		public   String  showReport2() {
			System.out.println("SeasonFinderOperationsController.showReport2() (POST)");
			return  "show_report2";
		}
	*/	
	
	
	
}
