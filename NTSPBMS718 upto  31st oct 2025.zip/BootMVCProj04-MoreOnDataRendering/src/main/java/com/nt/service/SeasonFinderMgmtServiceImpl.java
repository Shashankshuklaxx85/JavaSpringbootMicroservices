package com.nt.service;

import java.time.LocalDate;

import org.springframework.stereotype.Service;

@Service
public class SeasonFinderMgmtServiceImpl implements ISeasonFinderMgmtService {

	@Override
	public String findSeason() {
	   //get System Date
		LocalDate  date=LocalDate.now();
		//get current  month of the year
		int month=date.getMonthValue();
		//generate the season
		if(month>=3 && month<=6)
			return "Summer Season";
		else if(month>=7 && month<=9)
			return "Rainy Season";
		else
			return "Winter Season";
	}

}
