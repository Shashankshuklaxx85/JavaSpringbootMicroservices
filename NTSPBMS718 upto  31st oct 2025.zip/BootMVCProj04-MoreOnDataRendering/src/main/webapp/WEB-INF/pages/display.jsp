<%@page isELIgnored="false"  %>
<%@taglib  uri="http://java.sun.com/jsp/jstl/core"  prefix="c" %>

<h1  style="color:red;text-align:center"> Result Page </h1>
<br><br>

<c:if test="${!empty resultMsg}">
    <b> Result is ::<c:out value="${resultMsg}"/> </b>
 </c:if>
 
     <br>

<c:if  test="${!empty name}">
<b> name::  ${name}  </b><br>
</c:if>

<c:if  test="${!empty age}">
<b> age::  ${age}  </b><br>
</c:if>

<c:if  test="${!empty addrs}">
<b> Addrs::  ${addrs}  </b><br>
</c:if>


<c:if  test="${!empty nickNames}">
  <b> Nick names::</b>
   <c:forEach  var="name"  items="${nickNames}">
        <b> ${name} </b> <br>
   </c:forEach>
</c:if>

<br><br>

<c:if  test="${!empty friends }">
<b> Friends::</b> <br>
   <c:forEach  var="fr"  items="${friends}">
        <b> ${fr}, </b>  <br>
   </c:forEach>
</c:if>

<br><br>

<c:if  test="${!empty idDetails }">
   <b> IdDetails ::</b>
   <c:forEach  var="id"  items="${idDetails}">
        <b> ${id.key} ==  ${id.value} </b> <br>
   </c:forEach>
</c:if>

<c:if test="${!empty custData}">
    <b> Customer object data ::<c:out value="${custData}"/> </b> <br>
    <b> Customer object data values  ::  ${custData.cno}, ${custData.cname},${custData.caddrs}</b> <br>
    
 </c:if>
 
 <c:choose>
     <c:when  test="${!empty listCustData}">
          <b> ${listCustData.size()}  no.of customers are avaiable</b>
          <table  border="1"  align="center"  bgcolor="cyan">
             <tr>
                <th> cno  </th> <th> cname </th> <th> caddrs </th> <th> billamt </th>
             </tr>
             <tr>
                <c:forEach  var="cust"  items="${listCustData}">
                   <tr>
                      <td>${cust.cno}</td>
                      <td>${cust.cname}</td>
                      <td>${cust.caddrs}</td>
                      <td>${cust.billamt}</td>
                   </tr>
                </c:forEach>
             </tr>
          </table>
     </c:when>
     <c:otherwise>
          <b> Customers not found </b>
     </c:otherwise>
 </c:choose>




<a href="./">home</a>

