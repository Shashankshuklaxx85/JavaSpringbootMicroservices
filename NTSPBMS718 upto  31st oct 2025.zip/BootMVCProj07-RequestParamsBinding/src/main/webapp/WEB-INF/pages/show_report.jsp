<%@ page isELIgnored="false" %>


<h1  style="color:red;text-align:center"> Result page </h1>

<b> Request Param Values ::  ${param.no}, ${param.name}</b>
<br>
<a href="./">home</a>