//StudentOperationsController.java
package com.nt.controller;

import java.io.PrintWriter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class StudentOperationsController {
	

	
	/*@GetMapping("/report")
	public  String  process(@RequestParam("sno") int no,
			                                 @RequestParam("sname") String name) {
		System.out.println(no+"........"+name);
		//return LVN
		return "show_report";
	}*/
	
	/*@GetMapping("/report")
	public  String  process(@RequestParam(required = false,defaultValue = "1001") Integer no,
			                                 @RequestParam(required = false,defaultValue = "RRR")  String name) {
		System.out.println(no+"........"+name);
		//return LVN
		return "show_report";
	}*/
	
	/*	@GetMapping("/report")
		public  String  process(@RequestParam(required = false) Integer no,
				                                 @RequestParam(required = false,defaultValue = "RRR")  String name,
				                                  @RequestParam   String sadd[],
				                                  @RequestParam (name="sadd")  List<String> addrsList,
				                                  @RequestParam (name="sadd")  Set<String> addrsSet) {
		           System.out.println(no+"........"+name+"..."+Arrays.toString(sadd)+"...."+addrsList+"...."+addrsSet);
			//return LVN
			return "show_report";
		}
	*/
	
	@GetMapping("/report")
	public  String  process(@RequestParam(required = false) Integer no,
			                                 @RequestParam(required = false,defaultValue = "RRR")  String name,
			                                  @RequestParam   String sadd) {
		System.out.println(no+"......"+name+"....."+sadd);
		
		//return LVN
		return  "show_report";
	}
	
	@Autowired
	private  ServletContext  sc;
	
	@Autowired
	private  ServletConfig cg;
	
	
	@GetMapping("/process")
	public   void   sendDirectReponse(HttpServletRequest  req, HttpServletResponse res,HttpSession ses) throws Exception{
		//get PrintWriter
		PrintWriter pw=res.getWriter();
		//set response content type
		res.setContentType("text/html");
		// give  instrction to browser to make the content as downloadable file
		//res.setHeader("content-disposition", "attachment;fileName=abc.html");
		res.setHeader("content-disposition", "inline");
		//write output to res object
		pw.println("<b> web application name :: </b>"+sc.getContextPath());
		pw.println("<br><b>  Ds Logical name ::</b>"+cg.getServletName());
		pw.println("<br> <b>SEssion id ::</b>"+ses.getId());
		pw.println("<br> <b> Currrent request url ::: </b>"+req.getRequestURI());
		
	}
	
	
}
