//TestOperationsController.java
package com.nt.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/test-ops")
public class TestOperationsController {
	
	@GetMapping("/report1")
	public  String  showSalesReport() {
		System.out.println("TestOperationsController.showSalesReport()");
		return "test_report";
	}

}
