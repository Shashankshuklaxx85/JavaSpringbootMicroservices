package com.nt.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nt.service.ISeasonFinderMgmtService;

@Controller
@RequestMapping("/season-ops")
public class SeasonFinderOperationsController {
	@Autowired
	private ISeasonFinderMgmtService  seasonService;

	//@RequestMapping("/")
	@RequestMapping
	public  String showHome() {
		return "home";  //LVN
	}
	
	@RequestMapping("/season")
	public   String  showSeason(Map<String,Object> map) {
		//use service
		String msg=seasonService.findSeason();
		//keep the results in Model attribute
		map.put("resultMsg", msg);
		
		//return LVN
		return "display";
	}
	
		
	
	
}
