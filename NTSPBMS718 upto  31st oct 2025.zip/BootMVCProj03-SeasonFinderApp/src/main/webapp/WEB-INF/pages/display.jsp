<%@ page isELIgnored="false"%>

<h1  style="color:red;text-align:center"> Result Page </h1>
<br><br>

<b> result is :: ${resultMsg} </b> <br>

<br><br>

<a href="./">home</a>

