<%@ page isELIgnored="false"%>

<h1  style="color:red;text-align:center"> <a  href="season">Find Season</a> </h1>


<hr>

<a href="report1">send Request</a>  <br> <br>
<form action="report1" method="POST">
     <input type="submit"  value="send">
</form>
