<%@ page isELIgnored="false"  %>


<h1  style="color:red;text-align:center">  Student Registration Form Page  </h1>
<form action="register"  method="POST">
   <table   border="0"  align="center"  bgcolor="yellow">
        <tr>
           <th> Student number :: </th>
           <th>  <input type="text"  name="sno" placeholder="enter sno"> </th>  
       </tr>
       <tr>
           <th> Student Name :: </th>
           <th>  <input type="text"  name="sname"> </th>  
       </tr>
       <tr>
           <th> Student Address :: </th>
           <th>  <input type="text"  name="sadd"> </th>  
       </tr>
       <tr>
           <th> Student Avg :: </th>
           <th>  <input type="text"  name="avg"> </th>  
       </tr>
       <tr>
           <th> <input type="submit" value="send"> </th>
           <th>  <input type="reset"  value="cancel"> </th>  
       </tr>
     </table>
   
  </form>
