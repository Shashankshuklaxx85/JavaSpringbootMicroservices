<%@ page isELIgnored="false"  %>

<h1  style="color:red;text-align:center"> Spring Boot MVC App ---Form Data Binding </h1>

<a href="register"> register student</a>
