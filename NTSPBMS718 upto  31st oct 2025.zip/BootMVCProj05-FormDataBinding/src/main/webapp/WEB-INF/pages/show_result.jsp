<%@ page isELIgnored="false" %>

<h1  style="color:red;text-align:center"> Result Page  </h1>

<b> Result is :: ${result} </b> <br><br>
 <br>
<b> Model class obj data :: ${student}</b>
<br>
<b> Student name and avg :: ${student.sname}, ${student.avg}</b>


<a href="./">home</a>


