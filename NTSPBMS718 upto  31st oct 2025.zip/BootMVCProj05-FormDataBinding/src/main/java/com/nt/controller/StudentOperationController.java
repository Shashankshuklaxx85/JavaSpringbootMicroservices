//StudentOperationsController.java
package com.nt.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.nt.model.Student;
import com.nt.service.IStudentMgmtService;

@Controller
public class StudentOperationController {
	@Autowired
	private  IStudentMgmtService  studService;
	
	@GetMapping("/")  //handler method for home page
	public  String  showHomePage() {
		//return LVN
		return "welcome";
	}
	
	@GetMapping("/register")  //for launching the form page
	public  String   launchStudentFormPage(@ModelAttribute("stud") Student st) {
		//return LVN
		return  "register_student_form";
	}
	
	@PostMapping("/register")
	public  String   processFormpage(@ModelAttribute Student st,
			                                                       Map<String,Object> map) {
		//use  service
		String msg=studService.findResult(st);
		//keep the results in model attribute
		map.put("result", msg);
		//return LVN
		return "show_result";
	}

}
