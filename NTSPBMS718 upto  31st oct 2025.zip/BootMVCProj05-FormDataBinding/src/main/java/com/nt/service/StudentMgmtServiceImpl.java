package com.nt.service;

import org.springframework.stereotype.Service;

import com.nt.model.Student;

@Service
public class StudentMgmtServiceImpl implements IStudentMgmtService {
	

	@Override
	public String findResult(Student st) {
		if(st.getAvg()<30)
			return "fail";
		else if(st.getAvg()<50)
			return "Pass- Third Class";
		else if(st.getAvg()<60)
			return "Pass- SEcond Class";
		else
			return "Pass- First class";
	}

}
