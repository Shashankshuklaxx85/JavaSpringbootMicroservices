package com.nt.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
//@NoArgsConstructor
@AllArgsConstructor
public class Student {
	private Integer sno;
	private String sname;
	private  String sadd="hyd";
	private  Double avg;
	
	public  Student() {
		System.out.println("STudent:: 0-param constructor");
	}

}
