

<h1  style="color:red;text-align:center"> Welcome Spring  Boot MVC Application</h1>