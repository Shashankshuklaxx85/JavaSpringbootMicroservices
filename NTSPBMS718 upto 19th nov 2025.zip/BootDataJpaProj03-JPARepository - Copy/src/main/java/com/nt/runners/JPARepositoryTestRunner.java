package com.nt.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.JobSeeker;
import com.nt.service.IJobSeekerMgmtService;

@Component
public class JPARepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private   IJobSeekerMgmtService  jsService;

	@Override
	public void run(String... args) throws Exception {
		
		/*try {
			String msg=jsService.removeJobSeekersInBatch(List.of(567,1018));
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		/*try {
			 JobSeeker js=new JobSeeker();
			 js.setQlfy("BE"); //js.setLocation("hyd"); js.setJsaddrs("hyd");
			List<JobSeeker>  list=jsService.searchJobSeekersByData(js, true, "jsname");
			list.forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*try {
			JobSeeker  js=jsService.fetchJsById(10211);
			//System.out.println("JobSeeker Details ::"+js);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		*/
		
		try {
			JobSeeker proxy=jsService.showJsById(1021);
			System.out.println("proxy obj class name::"+proxy.getClass()+"..."+proxy.getClass().getSuperclass());
			//System.out.println("Js detials "+proxy.getJsname());
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}//main

}//class
