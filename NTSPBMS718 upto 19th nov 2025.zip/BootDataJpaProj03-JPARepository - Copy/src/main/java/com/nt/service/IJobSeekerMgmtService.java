package com.nt.service;

import java.util.List;

import com.nt.entity.JobSeeker;

public interface IJobSeekerMgmtService {
  
	public  String   removeJobSeekersInBatch(List<Integer> ids);
	public  List<JobSeeker>  searchJobSeekersByData(JobSeeker js, boolean ascOrder , String ...props);
	public   JobSeeker  fetchJsById(int id);
	public   JobSeeker  showJsById(int id);
	
    
}
