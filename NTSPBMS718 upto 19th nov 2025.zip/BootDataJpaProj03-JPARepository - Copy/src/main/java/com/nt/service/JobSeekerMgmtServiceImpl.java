package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nt.entity.JobSeeker;
import com.nt.repository.IJobSeekerRepository;

@Service
public class JobSeekerMgmtServiceImpl implements IJobSeekerMgmtService {
	@Autowired
	private  IJobSeekerRepository  jsRepo;

	@Override
	public String removeJobSeekersInBatch(List<Integer> ids) {
		List<JobSeeker> listJs=jsRepo.findAllById(ids);
		if(listJs.size()!=0) {
			jsRepo.deleteAllByIdInBatch(ids);
			return  listJs.size()+" no.of records are deleted";
		}
		return "No Records are found";
	}
	
	

	@Override
	public List<JobSeeker> searchJobSeekersByData(JobSeeker js, boolean ascOrder, String... props) {
		//create Sort object
		 Sort sort=Sort.by(ascOrder?Sort.Direction.ASC:Sort.Direction.DESC,props);
		 //create Example object
		 Example<JobSeeker>  example=Example.of(js);
		 //invoke the method
		 List<JobSeeker>  list=jsRepo.findAll(example,sort);
		return list;
	}
	
	@Override
	public JobSeeker fetchJsById(int id) {
		JobSeeker js=jsRepo.findById(id).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		return js;
	}
	
	@Override
	public JobSeeker showJsById(int id) {
		JobSeeker  proxy=jsRepo.getReferenceById(id);
		return proxy;
	}

	
	
}
