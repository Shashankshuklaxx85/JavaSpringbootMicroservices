package com.nt.runners;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.JobSeeker;
import com.nt.service.IJobSeekerMgmtService;

@Component
public class JobSeekerTestRunner implements CommandLineRunner {
	@Autowired
	private   IJobSeekerMgmtService  jsService;

	@Override
	public void run(String... args) throws Exception {
		/*	try {
				//create Entity object
				JobSeeker  js=new JobSeeker("rajesh", "vizag", "B.E",89990.0f,"raja@rani.com");
				//invoke the b.method
				String msg=jsService.regsiterJobSeeker(js);
				System.out.println(msg);
				 //Thread.sleep(60000);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		*/
		
			try {
				JobSeeker js1=new JobSeeker("ramesh", "hyd6","B.E", 50090.0f, "ramesh@g.com");
				JobSeeker js2=new JobSeeker("suresh", "vizag4","B.Tech", 70200.0f, "nagesh@g.com");
				JobSeeker js3=new JobSeeker("mahesh", "vizag2","B.E", 70000.0f, "mahesh@g.com");
				JobSeeker js4=new JobSeeker("1Ramesh", "hyd1","B.E", 50400.0f, "ramesh@g.com");
				JobSeeker js5=new JobSeeker("2Suresh", "vizag1","B.Tech", 71010.0f, "nagesh@g.com");
				JobSeeker js6=new JobSeeker("3Mahesh", "vizag3","B.E", 70100.0f, "mahesh@g.com");
				
				List<JobSeeker> list=List.of(js1,js2,js3,js4,js5,js6);
				String msg=jsService.registerJobSeekerGroup(list);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
		/*	try {
				long count=jsService.showJobSeekersCount();
				System.out.println("JobSeekers count is ::"+count);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
			System.out.println("=======================");
			try {
				String msg=jsService.checkJSAvailabilityById(1004);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
	/*	try {
			Iterable<JobSeeker>  list=jsService.showAllJobSeekers();
			list.forEach(js->{
				System.out.println(js);
			});
			System.out.println("=============");
			list.forEach(System.out::println);
			System.out.println("=============");
			StreamSupport.stream(list.spliterator(), false).forEach(System.out::println);
			System.out.println("=============");
			for(JobSeeker js:list) {
				System.out.println(js);
			}
		}//try
		catch(Exception e) {
			e.printStackTrace();
		} */
		
	/*try {
		//Iterable<JobSeeker> list=jsService.showAllJobSeekersByIds(List.of(1,1001,1002,5678,null));
		  //List<Integer> ids=Arrays.asList(1,1001,1002,5678,null);
		 List<Integer> ids=new ArrayList(); ids.add(1); ids.add(1001); ids.add(1002); ids.add(6789);
		  Iterable<JobSeeker> list=jsService.showAllJobSeekersByIds(ids);
		System.out.println(StreamSupport.stream(list.spliterator(), false).count()+" no.of records are retrieved");
		list.forEach(System.out::println);
	}
	catch(Exception e) {
		e.printStackTrace();
	}*/
	/*try {
		Optional<JobSeeker>  opt=jsService.showJsById(10011);
		if(opt.isPresent()) {
			JobSeeker st=opt.get();
			System.out.println("Js object data ::"+st);
		}
		else {
			System.out.println("Js not found");
		}
	}//try
	catch(Exception e) {
		e.printStackTrace();
	}*/
		
	/*	try {
			String msg=jsService.findJsById(1010);
			System.out.println("The output is ::"+msg);
		
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
	*/		
	/*try {
		JobSeeker js=jsService.fetchJsById(10011);
		System.out.println("Job seeker details ::"+js);
	}//try
	catch(Exception e) {
		e.printStackTrace();
	}*/
		
		/*try {
		   String  msg=jsService.hikeSalary(10011, 10.0f);
		   System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
	/*	try {
			JobSeeker js=new JobSeeker(101, "rudhiraj1", "navi-mumbai", "ME", 5454665.0f,"d11@gmail.com","pune");
			String msg=jsService.registerOrUpdateJS(js);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
	/*	try {
			String msg=jsService.removeJsById(1002);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
	/*		try {
				String msg=jsService.removeAllJsByIds(List.of(1011,1000,1001,1002));
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
	/*try {
		String  msg=jsService.removeAllJs();
		System.out.println(msg);
	}
	catch(Exception e) {
		e.printStackTrace();
	}*/
		
		
	}//main

}//class
