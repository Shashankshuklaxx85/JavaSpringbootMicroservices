package com.nt.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.JobSeeker;
import com.nt.exception.JobSeekerNotFoundException;
import com.nt.repository.IJobSeekerRepository;

@Service
public class JobSeekerMgmtServiceImpl implements IJobSeekerMgmtService {
	@Autowired
	private  IJobSeekerRepository  jsRepo;

	@Override
	public String regsiterJobSeeker(JobSeeker js) {
		System.out.println("Proxy obj class name::"+jsRepo.getClass()+"..."+Arrays.toString(jsRepo.getClass().getInterfaces())+"....."+Arrays.toString(jsRepo.getClass().getDeclaredMethods()));
		//save  the object
		JobSeeker  savedJs=jsRepo.save(js);
		//get the generated id value
		int idVal=savedJs.getJsid();
		return "JobSeeker object is saved with id value :"+idVal;
	}

	@Override
	public String registerJobSeekerGroup(Iterable<JobSeeker> list) {
		System.out.println("JobSeekerMgmtServiceImpl.registerJobSeekerGroup()");
		Iterable<JobSeeker> savedList=jsRepo.saveAll(list);
		// prepare List with id values
		List<Integer> ids=new ArrayList();
		/*savedList.forEach(js->{
			ids.add(js.getJsid());
		});*/
		  ids=StreamSupport.stream(savedList.spliterator(), false).map(JobSeeker::getJsid).toList();
		//return the message
		return  ids.size()+" no.of  JobSeekers are saved with id values::"+ids;
	}
	
	@Override
	public String checkJSAvailabilityById(int id) {
		System.out.println("JobSeekerMgmtServiceImpl.checkJSAvailabilityById()");
		boolean flag=jsRepo.existsById(id);
		return  flag?"JobSeeker is found":"Job seeker is not found";
	}
	@Override
	public long showJobSeekersCount() {
		System.out.println("JobSeekerMgmtServiceImpl.showJobSeekersCount()");
		return jsRepo.count();
	}

	@Override
	public Iterable<JobSeeker> showAllJobSeekers() {
		Iterable<JobSeeker>  list=jsRepo.findAll();
	    List<JobSeeker>  sortedList=StreamSupport.stream(list.spliterator(), false).sorted((js1,js2)->js1.getJsname().compareTo(js2.getJsname())).toList();	
	    return  sortedList;
	}
	
	@Override
	public Iterable<JobSeeker> showAllJobSeekersByIds(Iterable<Integer> ids) {
		Iterable<JobSeeker>  list=jsRepo.findAllById(ids);
		return list;
	}
	
	@Override
	public Optional<JobSeeker> showJsById(int id) {
		Optional<JobSeeker>  opt=jsRepo.findById(id);
		return opt;
	}
	
	@Override
	public String findJsById(int id) {
		Optional<JobSeeker>  opt=jsRepo.findById(id);
		if(opt.isEmpty())
			 return "Job seeker not found";
		else
			return "Job Seeker  found and the details are ::"+opt.get();
	}
	
	@Override
	public JobSeeker fetchJsById(int id) {
		/*	Optional<JobSeeker>  opt=jsRepo.findById(id);
			if(opt.isEmpty())
				 throw new IllegalArgumentException("Invalid js id");
			else
				return opt.get();
		*/		
		//JobSeeker js=jsRepo.findById(id).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		//JobSeeker js=jsRepo.findById(id).orElseThrow(()->new JobSeekerNotFoundException("Invalid ID"));
		  JobSeeker  js=jsRepo.findById(id).orElse(new JobSeeker("xxxx","freelancer","uuuuu",11111.0f,"x@y.com"));
		return js;
	}
	
	@Override
	public String hikeSalary(int id, float hikePercent) {
		//load the object
		 JobSeeker  js=jsRepo.findById(id).orElseThrow(()->new JobSeekerNotFoundException("Invalid Id"));
		  js.setExpectedSalary(js.getExpectedSalary()+(js.getExpectedSalary()*hikePercent/100.0f));
		  jsRepo.save(js);
		  return  "JobSeeker is updated with salary ::"+js.getExpectedSalary();
	}
	
	@Override
	public String registerOrUpdateJS(JobSeeker js) {
		if(jsRepo.existsById(js.getJsid())) {
			jsRepo.save(js);
			return  "JobSeeker object is updated";
		}
		else {
			jsRepo.save(js);
			return  "JobSeeker object is saved";
		}
	}

	/*	@Override
		public String removeJsById(int id) {
			// Load the object
			boolean flag=jsRepo.existsById(id);
			// delete the object
			if(flag) {
				jsRepo.deleteById(id);
				return "Jobseeker is found and deleted";
			}
			else {
				return "Jobseeker is not found";
			}
		}
	*/
	
	@Override
	public String removeJsById(int id) {
		// Load the object
		JobSeeker  js=jsRepo.findById(id).orElseThrow(()-> new JobSeekerNotFoundException("Invalid Id"));
		// delete the object
		  jsRepo.delete(js);
		  return "JobSeeker is found and Deleted";
	}
	
	/*@Override
	public String removeAllJsByIds(Iterable<Integer> ids) {
		//Load objs
		Iterable<JobSeeker>  listJs=jsRepo.findAllById(ids);
		//get the count of objects
		long count=StreamSupport.stream(listJs.spliterator(), false).count();
		if(count==0)
			return "No Records  found for deletion";
		else {
			  jsRepo.deleteAllById(ids);
			return  count+" no.of records are deleted";
		}
	}*/
	
	@Override
	public String removeAllJsByIds(Iterable<Integer> ids) {
		//Load objs
		Iterable<JobSeeker>  listJs=jsRepo.findAllById(ids);
		//get the count of objects
		long count=StreamSupport.stream(listJs.spliterator(), false).count();
		if(count==0)
			return "No Records  found for deletion";
		else {
			  jsRepo.deleteAll(listJs);
			return  count+" no.of records are deleted";
		}
	}
	
	@Override
	public String removeAllJs() {
		long count=jsRepo.count();
		if(count==0)
			return "Records not found for deletion";
		else {
			jsRepo.deleteAll();
			return count+" no.of records found and deleted";
		}
	}

}
