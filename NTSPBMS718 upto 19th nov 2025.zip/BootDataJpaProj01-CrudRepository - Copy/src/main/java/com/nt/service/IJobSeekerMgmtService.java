package com.nt.service;

import java.util.Optional;

import com.nt.entity.JobSeeker;

public interface IJobSeekerMgmtService {
    public  String regsiterJobSeeker(JobSeeker  js);
    public  String registerJobSeekerGroup(Iterable<JobSeeker> list);
    public  long  showJobSeekersCount();
    public   String   checkJSAvailabilityById( int id);
    public   Iterable<JobSeeker>  showAllJobSeekers();
    public  Iterable<JobSeeker>  showAllJobSeekersByIds(Iterable<Integer> ids);
    public    Optional<JobSeeker>  showJsById(int id);
    public   String    findJsById(int id);
    public   JobSeeker  fetchJsById(int id);
    public   String  hikeSalary(int id , float hikePercent);
    public  String   registerOrUpdateJS(JobSeeker js);
    public  String    removeJsById(int id);
    public  String   removeAllJsByIds(Iterable<Integer> ids);
    public  String  removeAllJs();
    
}
