package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootIocProj08LocalTxMgmtApp {

	public static void main(String[] args) {
		SpringApplication.run(BootIocProj08LocalTxMgmtApp.class, args);
	}

}
