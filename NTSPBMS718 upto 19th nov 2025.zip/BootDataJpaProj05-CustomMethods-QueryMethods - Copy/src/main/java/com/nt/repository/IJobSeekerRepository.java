package com.nt.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.JobSeeker;

import jakarta.transaction.Transactional;

public interface IJobSeekerRepository extends JpaRepository<JobSeeker, Integer> {
	
	@Query("from JobSeeker where  ?1 in (?2, ?3,?4) order  by jsaddrs  ")
	public   List<JobSeeker> showJsByAddrs(String prop, String city1, String city2,String city3);
	
	//@Query("from JobSeeker where  jsaddrs in (:loc1, :loc2, :loc3) order  by jsaddrs  ")
	/*public   List<JobSeeker> showJsByAddrs(@Param("loc1") String city1,
			                                                                @Param("loc2")String city2,
			                                                                @Param("loc3")String city3);
	*/
	/*@Query("select  js from JobSeeker   js where  js.jsaddrs in (:city1, :city2, :city3) order  by js.jsaddrs  ")
	public   List<JobSeeker> showJsByAddrs( String city1,
			                                                                String city2,
			                                                                String city3);
	*/	
	
	  //Bulk Entity Query
	@Query("from JobSeeker  where expectedSalary>=:start and expectedSalary<=:end")
	public   List<JobSeeker>  showJsBySalaryRange(double start,double end);  
	
	  // Bulk scalar query giving  specific multiple col values
	@Query("select  jsid,jsname,expectedSalary from JobSeeker  where expectedSalary>=:start and expectedSalary<=:end")
	public   List<Object[]>  showJsDataBySalaryRange(double start,double end);  
	
	// Bulk scalar query giving  specific single col values
	@Query("select  jsname from JobSeeker  where expectedSalary>=:start and expectedSalary<=:end")
	public   List<String>  showJsNameBySalaryRange(double start,double end);  
	
	// Single row  entity  Query
	@Query("from JobSeeker  where email=:mail")
	public   Optional<JobSeeker>   showJsByEmail(String mail);
	
	// Single row  Scalar Query selecting specific multiple col values
		@Query("select jsid,jsname,email from JobSeeker  where email=:mail")
		public   Optional<Object>   showJsDataByEmail(String mail);
	
		// Single row  Scalar Query selecting specific single col value
		@Query("select jsname from JobSeeker  where email=:mail")
		public   Optional<String>   showJsNameByEmail(String mail);
		
		// working with aggregate functions
		@Query("select  distinct count(jsname)  from  JobSeeker")
		public   long  getUniqueJsCount();
		
		@Query("select  count(*) , max(expectedSalary) ,min(expectedSalary),sum(expectedSalary),avg(expectedSalary)  from  JobSeeker")
		public  Object   getJsAggregateData();
		
		//non -select HQL Queries
	
		@Query("update  JobSeeker  set expectedSalary=expectedSalary+(expectedSalary*:percentage/100.0)  where jsaddrs=:city")
	    @Modifying
	    @Transactional
		public  int  updateExpectedSalaryByJsAdddrs(String city,double percentage);
		
		@Query("delete from  JobSeeker where expectedSalary between :start and :end")
	    @Modifying
	    @Transactional
		public   int   deleteJsInfoByExpectedSalaryRange(double start,double end);
		
		
		//Native  SQL Queries
		@Query(value="select sysdate from dual",nativeQuery = true)  //for oracle
		//@Query(value="select now() from dual",nativeQuery = true)  //for mysql
		public    LocalDateTime   showSystemDateTime();
		
		
		
		
		
	
	
	
	
	
	
}
