package com.nt.runners;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.repository.IJobSeekerRepository;

@Component
public class CustomQueryMethodsTestRunner implements CommandLineRunner {

    @Autowired
	private  IJobSeekerRepository  jsRepo;

	
	@Override
	public void run(String... args) throws Exception {
	
		/*try {
		 List<JobSeeker>  list=jsRepo.showJsByAddrs("jsaddrs","hyd", "delhi", "vizag");
		 list.forEach(System.out::println);
		}
		catch(Exception e) {
		 e.printStackTrace();
		}*/
		/*try {
			System.out.println("=====Bulk Entity operation=========");
			jsRepo.showJsBySalaryRange(10000.0, 200000.0).forEach(System.out::println);
			
			System.out.println("=====Bulk Scalar operation (specific mulitple col values)=========");
			jsRepo.showJsDataBySalaryRange(10000.0, 200000.0).forEach(rowData->{
			      for(Object row:rowData) {
			    	  System.out.print(row+" ");
			      }
			      System.out.println();
			});
			System.out.println("=====Bulk Scalar operation (specific single col values)=========");
			jsRepo.showJsNameBySalaryRange(10000.0, 200000.0).forEach(System.out::println);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		*/
		/*try {
			System.out.println("=====Single Row Entity operation=========");
			
			Optional<JobSeeker> opt1=jsRepo.showJsByEmail("suri@g.com");
			if(opt1.isEmpty())
				System.out.println("record not found");
			else
				System.out.println("record found::"+opt1.get());
			
			System.out.println("=====Single Row scalar operation (specicific multiple col values)=========");
			
			Optional<Object> opt2=jsRepo.showJsDataByEmail("suri@g.com");
			if(opt2.isEmpty())
				System.out.println("Record not  found");
			else {
				  Object row[]=(Object[])opt2.get();
				System.out.println("Record data found ::"+Arrays.toString(row));
			}
			
			System.out.println("=====Single Row scalar operation (specicific single col value)=========");
			Optional<String> opt3=jsRepo.showJsNameByEmail("suri@g.com");
			if(opt3.isEmpty())
				System.out.println("Record not  found");
			else {
				System.out.println("Record data found ::"+opt3.get());
			}
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
		*/
		/*	try {
			  System.out.println("Unique JobSeekers  count::"+jsRepo.getUniqueJsCount());
			  System.out.println("---------------------------------");
			  Object data[]=(Object[])jsRepo.getJsAggregateData();
			  System.out.println("count of records:"+data[0]);
			  System.out.println("max of expectedSalary:"+data[1]);
			  System.out.println("min of expectedSalary:"+data[2]);
			  System.out.println("sum of expectedSalary:"+data[3]);
			  System.out.println("avg of expectedSalary:"+data[4]);
			}
			 catch(Exception e) {
				 e.printStackTrace();
			 }*/
		/*	try {
				int count=jsRepo.updateExpectedSalaryByJsAdddrs("hyd",10.0);
				System.out.println("no.of records that are updated::"+count);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		/*	try {
				int count=jsRepo.deleteJsInfoByExpectedSalaryRange(10000.0,200000.0);
				System.out.println("No.of  records that are effected::"+count);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		try {
			LocalDateTime  ldt=jsRepo.showSystemDateTime();
			System.out.println("System Date and Time::"+ldt);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}//run

}//class
