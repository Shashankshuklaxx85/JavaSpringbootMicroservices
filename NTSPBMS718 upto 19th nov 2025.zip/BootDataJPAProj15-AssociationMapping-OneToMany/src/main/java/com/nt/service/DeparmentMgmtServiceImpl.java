package com.nt.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nt.entity.Department;
import com.nt.entity.Employee;
import com.nt.repository.IDepartmentRepository;
import com.nt.repository.IEmployeeRepository;


@Service("deptService")
public class DeparmentMgmtServiceImpl implements IDepartmentMgmtService {
	@Autowired
	private IDepartmentRepository deptRepo;
	@Autowired
	private  IEmployeeRepository  empRepo;

	@Override
	public String saveDepartmentAndItsEmployees(Department dept) {
		int idVal=deptRepo.save(dept).getDid();
		return "Dept and its employees are saved with the id value ::"+idVal;
	}
	
	@Override
	public String saveEmployeesAndItsDepartment(List<Employee> emps) {
		List<Employee> savedList=empRepo.saveAll(emps);
		//  gather only id values  from the savedList
		List<Integer> ids=savedList.stream().map(Employee::getEid).toList();
		return ids.size()+"  no.of  employees are saved pointing to Department";
	}
	
	@Override
	public List<Department> showAllDepartmentAndTheirEmployees() {
		return deptRepo.findAll();
	}
	
	@Override
	public List<Employee> showAllEmployeesAndTheirDepartment() {
		return empRepo.findAll();
	}
	
	@Override
	public String deleteDepartmentAndItsEmployees(int did) {
		 //Load the Department
		  Department  dept=deptRepo.findById(did).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		 //delete  and Department and its Employees
		  deptRepo.delete(dept);
		return did+" Department and its Employees are Deleted";
	}
	
	@Override
	public String deleteEmployeesAndItsDepartment(List<Integer> eids) {
		//Load the objects
		List<Employee> list=empRepo.findAllById(eids);
		if(list.size()!=0) {
		   //delete all childs
		  empRepo.deleteAllById(eids);
		  return  eids+" Employees and their Department is  Deleted";
		}
		return eids+" Employees are not found";
	}
	
	@Override
	public String deleteAllEmployeesOfDepartment(int did) {
		 //Load the Department
		  Department  dept=deptRepo.findById(did).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
	     // get the childs of  a parent
		  Set<Employee> childs=dept.getEmps();
		  //delete only  childs
		  empRepo.deleteAllInBatch(childs);
		return "All the employees of "+did+" Department are deleted";
	}
	@Override
	public String deleteOneEmployeesOfADepartment(int did, int eid) {
		 //Load the Department
		  Department  dept=deptRepo.findById(did).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
	    //Load the Employee
		   Employee  emp=empRepo.findById(eid).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		   // remove  parent from the child
		     emp.setDept(null);
		     //update the  update
		     empRepo.delete(emp);
		     
		 return eid+" Employee of "+did+" Department is removed";
	}
	
	@Override
	public String addNewEmployeeToTheDepartment(int did, Employee emp) {
		 //Load the Department
		  Department  dept=deptRepo.findById(did).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		  //get existing emps of the Dept
		  Set<Employee> childs=dept.getEmps();
		  //add new Emp to  the department
		  childs.add(emp);
		  //link new Employee with Department
		  emp.setDept(dept);
		  //update the  departement
		  deptRepo.save(dept);
		  
				return "New Employee is saved to the existing Department "+did;
	}
	
	@Override
	public String addNewEmployeesToTheDepartment(int did, List<Employee> list) {
		 //Load the Department
		  Department  dept=deptRepo.findById(did).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		  //get existing emps of the Dept
		  Set<Employee> childs=dept.getEmps();
		// link  new childs with parent
		//add  new employees to existing list of  emps of a department
		  
		  list.forEach(emp->{
			  emp.setDept(dept);
			  childs.add(emp);
		  });
		  //update the  Deparemtn
		  deptRepo.save(dept);
		return list.size()+" employees are added newly to "+did+" Department";
	}
	
	@Override
  public String transterEmployeeToAnotherDepartment(int eid, int did1, int did2) {
		 //Load the Department1
		  Department  dept1=deptRepo.findById(did1).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		//Load the Department2
		  Department  dept2=deptRepo.findById(did2).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		//Load the Employee
		   Employee  emp=empRepo.findById(eid).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		   //chanage the department of the Employee
		   emp.setDept(dept2);
		   //update the employee
		   empRepo.save(emp);
			return eid+" Employee is trasnfered to"+did1+" Department from "+did2+" Department";
	}
	

}
