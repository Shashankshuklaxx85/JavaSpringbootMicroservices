package com.nt.service;

import java.util.List;

import com.nt.entity.Department;
import com.nt.entity.Employee;

public interface IDepartmentMgmtService {
   public  String  saveDepartmentAndItsEmployees(Department dept);
   public  String   saveEmployeesAndItsDepartment(List<Employee> emps);
   public  List<Department>  showAllDepartmentAndTheirEmployees();
   public  List<Employee>  showAllEmployeesAndTheirDepartment();
   public  String deleteDepartmentAndItsEmployees(int did);
   public  String deleteEmployeesAndItsDepartment(List<Integer> eids);
   public   String deleteAllEmployeesOfDepartment(int did);
   public   String deleteOneEmployeesOfADepartment(int did,int eid);
   public  String  addNewEmployeeToTheDepartment(int did, Employee emp);
   public  String  addNewEmployeesToTheDepartment(int did, List<Employee> list);
   public  String  transterEmployeeToAnotherDepartment(int eid,int did1,int did2);
   
   
   
   
}
