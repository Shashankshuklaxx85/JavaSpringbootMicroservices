//Employee.java
package com.nt.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="OTM_EMPLOYEE")
@Setter
@Getter
@RequiredArgsConstructor
public class Employee {
	@Id
	@SequenceGenerator(name="gen1",sequenceName = "EID_SEQ",initialValue = 100,allocationSize = 1)
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
	private Integer eid;
	
	@Column(length = 30)
	@NonNull
	private String ename;
	@NonNull
	private  Float salary;
	@Column(length = 30)
	@NonNull
	private  String desg;
	
	@ManyToOne(targetEntity = Department.class,cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="DEPT_ID",referencedColumnName = "DID")
	private Department dept;  //for building many to one association

	public Employee() {
		System.out.println("Employee:: 0-param constructor::"+this.getClass());
	}
	
	//toString (alt+shift+s,s)
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", salary=" + salary + ", desg=" + desg + "]";
	}
	

}
