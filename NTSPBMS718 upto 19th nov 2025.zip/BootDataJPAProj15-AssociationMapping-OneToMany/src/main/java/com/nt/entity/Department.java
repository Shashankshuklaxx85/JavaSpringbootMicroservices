//Department.java
package com.nt.entity;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
@Entity
@Table(name="OTM_DEPT")
@Setter
@Getter
@RequiredArgsConstructor
public class Department {
	@Id
	@SequenceGenerator(name="gen1",initialValue = 1,allocationSize = 1,sequenceName = "DID_SEQ")
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
   private Integer did;
	@NonNull
	@Column(length = 30)
   private  String name;
	@NonNull
	@Column(length = 30)
   private  String  location;
	
	
	@OneToMany(targetEntity = Employee.class,cascade = CascadeType.ALL,mappedBy = "dept",fetch = FetchType.EAGER)
   private  Set<Employee>  emps;  //for building one to many association
   
	
	public  Department() {
		System.out.println("Department :: 0-param constructor::"+this.getClass());
	}
	
   //toString()  (alt+Shift+s,s)
   @Override
   public String toString() {
     	return "Department [did=" + did + ", name=" + name + ", location=" + location + "]";
   }
   
}
