package com.nt.runners;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Department;
import com.nt.entity.Employee;
import com.nt.service.DeparmentMgmtServiceImpl;
import com.nt.service.IDepartmentMgmtService;

@Component
public class OneToManyAssociationTestRunner implements CommandLineRunner {

	@Autowired
   private   IDepartmentMgmtService  service;


	@Override
	public void run(String... args) throws Exception {
		/*//save the objects (parent to child)
		Department dept=new Department("HR", "hyd");
		Employee emp1=new Employee("karan", 80000.0f, "MANAGER");
		Employee emp2=new Employee("suman", 90000.0f, "PROGRRAMMER");
		//link childs with parent
		emp1.setDept(dept); emp2.setDept(dept);
		//link childs to parent
		dept.setEmps(Set.of(emp1,emp2));
		
		//invoke the method
		try {
			String msg=service.saveDepartmentAndItsEmployees(dept);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*//save the objects (child  to parent)
		Department dept=new Department("Sales", "hyd");
		Employee emp1=new Employee("jani", 80000.0f, "MANAGER");
		Employee emp2=new Employee("lokesh", 90000.0f, "PROGRRAMMER");
		// set  parent with childs
		emp1.setDept(dept); emp2.setDept(dept);
		//set  childs to  parent
		Set<Employee> childs=new HashSet<Employee>();
		childs.add(emp1); childs.add(emp2);
		dept.setEmps(childs);
		//prepare  List of childs
		List<Employee> empsList=Arrays.asList(emp1,emp2);
		
		try {
			String msg=service.saveEmployeesAndItsDepartment(empsList);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		/*	try {
				List<Department> list=service.showAllDepartmentAndTheirEmployees();
				list.forEach(dept->{
					System.out.println("parent:::"+dept);
					System.out.println("-----------");
					Set<Employee> childs=dept.getEmps();
					childs.forEach(emp->{
						System.out.println("child::"+emp);
					});
				  System.out.println("====================");
				});
			}
			catch(Exception  e) {
				e.printStackTrace();
			}*/
		
		/*		try {
					List<Employee>  childsList=service.showAllEmployeesAndTheirDepartment();
					childsList.forEach(emp->{
						System.out.println("Child::"+emp);
						System.out.println("----------------");
						Department  dept=emp.getDept();
						System.out.println("Parent::"+dept);
						System.out.println("==========");
					});
					
				}
				catch(Exception e) {
					e.printStackTrace();
				}*/
		
		/*try {
			String msg=service.deleteDepartmentAndItsEmployees(1);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		/*try {
			String msg=service.deleteEmployeesAndItsDepartment(List.of(104,105));
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*	try {
				String msg=service.deleteAllEmployeesOfDepartment(3);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		/*		try {
					String msg=service.deleteOneEmployeesOfADepartment(6, 109);
					System.out.println(msg);
				}
				catch(Exception e) {
					e.printStackTrace();
				}*/

		/*try {
			Employee  emp=new Employee("naresh",455506.0f, "SALESMAN");
			String msg=service.addNewEmployeeToTheDepartment(6, emp);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*	try {
				Employee  emp1=new Employee("suresh",455106.0f, "SALESMAN");
				Employee  emp2=new Employee("mahesh",455106.0f, "CLERK");
				List<Employee>  list=Arrays.asList(emp1,emp2);
				String msg=service.addNewEmployeesToTheDepartment(6, list);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		try {
			String msg=service.transterEmployeeToAnotherDepartment(112, 6, 3);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}//main
}//class
