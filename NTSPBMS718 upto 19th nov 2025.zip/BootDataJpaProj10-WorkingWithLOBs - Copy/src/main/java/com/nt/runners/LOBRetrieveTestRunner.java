package com.nt.runners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.MarriageSeeker;
import com.nt.service.IMatrimonyMgmtService;

@Component
public class LOBRetrieveTestRunner implements CommandLineRunner {
	@Autowired
	private  IMatrimonyMgmtService  msService;

	@Override
	public void run(String... args) throws Exception {
		try(Scanner sc=new Scanner(System.in)){
			   System.out.println("enter  marriage seeker id::");
			   int id=sc.nextInt();
			   
			   //invoke b.method
			   MarriageSeeker seeker=msService.showMarraigeSeekerDetailsById(id);
			     System.out.println(seeker.getAid()+"...."+seeker.getName()+"...."+seeker.getAddrs()+"...."+seeker.getSingle());
			     byte[]  photoContent=seeker.getPhoto();
			     char[]  resumeContent=seeker.getResume();
			     try(FileOutputStream fos=new FileOutputStream("new_photo.jpeg");
			    		 FileWriter writer=new FileWriter("new_resumt.txt");
			    		 ){
			    	    //write the content
			    	 fos.write(photoContent);
			    	 System.out.println("Photo is retrived and saved");
			    	 writer.write(resumeContent);
			    	 System.out.println("Resume is retrived and saved");
			     }
			  }
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
