package com.nt.runners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.MarriageSeeker;
import com.nt.service.IMatrimonyMgmtService;

//@Component
public class LOBInsertionTestRunner implements CommandLineRunner {
	@Autowired
	private  IMatrimonyMgmtService  msService;

	@Override
	public void run(String... args) throws Exception {
		try(Scanner sc=new Scanner(System.in)){
			   System.out.println("enter  marriage seeker name::");
			   String name=sc.next();
			   System.out.println("enter  marriage seeker addrs::");
			   String addrs=sc.next();
			   System.out.println("enter  marriage seeker DOB(dd-MM-yyyy)::");
			   String sdob=sc.next(); 
			   DateTimeFormatter  formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
			   LocalDate  ldob=LocalDate.parse(sdob, formatter);
			   System.out.println("enter  marriage seeker Photo Path::");
			   String photoPath=sc.next();
			   System.out.println("enter  marriage seeker resume Path::");
			   String resumePath=sc.next();
			   System.out.println("Is  marriage seeker Single?::");
			   Boolean flag=sc.nextBoolean();
			   
			   //convert photo file content  to byte[]
			       //get  Photo file lengnt
			      File  photoFile=new File(photoPath);
			      int length=(int) photoFile.length();
			      byte[]  photoContent=new byte[length];
			   try(FileInputStream  fis=new FileInputStream(photoPath)){
				        photoContent=fis.readAllBytes();
			   }
			   
			 //convert  resume file content  to char[]
			   File  resumeFile=new File(resumePath);
			   length=(int)resumeFile.length();
			   char[] resumeContent=new char[length];
			   try(FileReader  reader=new FileReader(resumeFile)) {
				   reader.read(resumeContent);
			   }
			   //prepare entity class object
			   MarriageSeeker  seeker=new MarriageSeeker(name, addrs, ldob, flag, photoContent, resumeContent);
			   //invoke b.method
			   String msg=msService.registerMarriageSeeker(seeker);
			   System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
