package com.nt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.MarriageSeeker;
import com.nt.repository.IMarriageSeekerRepository;

@Service
public class MatrimonyMgmtServiceImpl implements IMatrimonyMgmtService {
	@Autowired
	  private  IMarriageSeekerRepository  msRepo;

	@Override
	public String registerMarriageSeeker(MarriageSeeker seeker) {
		int idVal=msRepo.save(seeker).getAid();
		return "Marriage Seeker is saved with the id value ::"+idVal;
	}

	@Override
	public MarriageSeeker showMarraigeSeekerDetailsById(int id) {
		return msRepo.findById(id).orElseThrow(()->new IllegalArgumentException("Invalid id"));
	}

}
