package com.nt.entity;

import java.io.Serializable;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name="JPA_MARRIAGE_SEEKER")
public class MarriageSeeker  implements Serializable {
	@Id
	@GeneratedValue
	private  Integer aid;
	
	@Column(length = 30)
	@NonNull
	private  String  name;
	
	@Column(length = 30)
	@NonNull
	private  String addrs;
	@NonNull
	private  LocalDate dob;
	@NonNull
	private  Boolean  single;
    @Lob
    @NonNull
	private  byte[]  photo;
    @Lob
    @NonNull
	private char[]  resume;

}
