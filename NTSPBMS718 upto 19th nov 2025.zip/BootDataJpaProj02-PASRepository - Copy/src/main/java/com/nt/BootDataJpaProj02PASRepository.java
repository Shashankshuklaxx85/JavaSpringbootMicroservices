package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj02PASRepository {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj02PASRepository.class, args);
	}

}
