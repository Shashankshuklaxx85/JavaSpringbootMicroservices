package com.nt.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.nt.entity.JobSeeker;
import com.nt.service.IJobSeekerMgmtService;

@Component
public class PASRepoTestRunner implements CommandLineRunner {
	@Autowired
	private   IJobSeekerMgmtService  jsService;

	@Override
	public void run(String... args) throws Exception {
		
		/*try {
			//Iterable<JobSeeker>  listJs=jsService.showJobSeekersAsSorted(false, "jsname");
			Iterable<JobSeeker>  listJs=jsService.showJobSeekersAsSorted(true, "jsname","jsaddrs");
			listJs.forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		*/
		
		/*	try {
				Page<JobSeeker>  page=jsService.showJsDetaisByPagination(0, 3);
				System.out.println("records of :"+(page.getNumber()+1)+"/"+page.getTotalPages());
				page.getContent().forEach(System.out::println);
				System.out.println("---------------------");
				System.out.println(" is the current page is first page ::"+page.isFirst());
				System.out.println(" is the current page is last page ::"+page.isLast());
				System.out.println(" current page no.of records ::"+page.getNumberOfElements());
				System.out.println("Is current page is having previous page::"+page.hasPrevious());
				System.out.println("Is current page is having next page::"+page.hasNext());
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		/*	try {
				Page<JobSeeker>  page=jsService.showJsDetaisByPaginationAndSorted(1, 3,true,"jsname");
				page.getContent().forEach(System.out::println);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		try {
			 jsService.showAllPagesData(2);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
				
	}//main

}//class
