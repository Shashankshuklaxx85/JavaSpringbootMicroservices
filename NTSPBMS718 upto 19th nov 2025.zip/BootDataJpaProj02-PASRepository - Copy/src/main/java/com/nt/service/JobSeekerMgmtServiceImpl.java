package com.nt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nt.entity.JobSeeker;
import com.nt.repository.IJobSeekerRepository;

@Service
public class JobSeekerMgmtServiceImpl implements IJobSeekerMgmtService {
	@Autowired
	private  IJobSeekerRepository  jsRepo;

	@Override
	public Iterable<JobSeeker> showJobSeekersAsSorted(boolean ascOrder, String... props) {
		//prepare the Sort object
		Sort sort=Sort.by(ascOrder?Sort.Direction.ASC:Sort.Direction.DESC,props);
		//execute the logic
		return jsRepo.findAll(sort);
	}

	@Override
	public Page<JobSeeker> showJsDetaisByPagination(int pageNo, int pageSize) {
		//create Pageable object
		Pageable pageable=PageRequest.of(pageNo, pageSize);
		//get the requested page records
		Page<JobSeeker>  page=jsRepo.findAll(pageable);
		return page;
	}
	
	@Override
	public Page<JobSeeker> showJsDetaisByPaginationAndSorted(int pageNo, int pageSize, 
			                                                                                             boolean ascOrder,String... props) {
		//create Sort object
		Sort sort=Sort.by(ascOrder?Sort.Direction.ASC:Sort.Direction.DESC, props);
		//create  Pageable object having  pagination and Sorting info
		Pageable pageable=PageRequest.of(pageNo, pageSize, sort);
		//invoke the logics
		Page<JobSeeker>  page=jsRepo.findAll(pageable);
		return page;
	}
	
	@Override
	public void showAllPagesData(int pageSize) {
	  // get total  records count
		long count=jsRepo.count();
		// get total pages count
		long pagesCount=count/pageSize;
		if(count%pageSize!=0)
			    pagesCount++;
		
		//display the records of  all the pages
		for(int i=0;i<pagesCount;++i) {
			//create Pageable object for  each page
			Pageable pageable= PageRequest.of(i, pageSize);
			//get the Page<T> object having each page records
			Page<JobSeeker>  page=jsRepo.findAll(pageable);
			System.out.println("Records of "+(i+1) +"/"+page.getTotalPages()+" page");
			page.getContent().forEach(System.out::println);
			System.out.println("-------------------------------");
		}
		
	}
	

	
}
