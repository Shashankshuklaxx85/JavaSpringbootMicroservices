package com.nt.service;

import org.springframework.data.domain.Page;

import com.nt.entity.JobSeeker;

public interface IJobSeekerMgmtService {
    public Iterable<JobSeeker>  showJobSeekersAsSorted(boolean ascOrder,String  ... props);   
    public   Page<JobSeeker>   showJsDetaisByPagination(int pageNo, int pageSize);
    public   Page<JobSeeker>   showJsDetaisByPaginationAndSorted(int pageNo, int pageSize,
    		                                                                                                                  boolean ascOrder,String ...props);
    public   void   showAllPagesData(int pageSize);
    
}
