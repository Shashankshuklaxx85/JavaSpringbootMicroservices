package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj17InteractingWithTwoDBsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj17InteractingWithTwoDBsApplication.class, args);
	}

}
