package com.nt.runners;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Employee;
import com.nt.service.EmployeeMgmtServiceImpl;
import com.nt.service.IEmployeeMgmtService;

@Component
public class CollectionMappingTestRunner implements CommandLineRunner {

    @Autowired
	private IEmployeeMgmtService   empService;

    
	@Override
	public void run(String... args) throws Exception {
		/*	try {
				// create the Entity object
				List<String> friendsList=List.of("rajesh1","suresh1","mahesh1");
				Set<Long>  phonesList=Set.of(999999919L,88888888881L,77777777772L);
				Map<String,String>  idDetailsMap=Map.of("aadhar","46561GFDF","passport","414666FFF");
				Employee  emp=new Employee("mahesh","hyd1",friendsList,phonesList,idDetailsMap);
				//invoke the service class method
				String  msg=empService.registerEmployee(emp);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		try {
			empService.showAllEmployees().forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
