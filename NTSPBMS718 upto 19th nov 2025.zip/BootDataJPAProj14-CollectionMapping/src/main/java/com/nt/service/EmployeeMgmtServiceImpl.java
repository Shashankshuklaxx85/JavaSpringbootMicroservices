//IEmplpyeeMgmtServiceImpl.java
package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Employee;
import com.nt.repository.IEmployeeRepository;

@Service("empService")
public class EmployeeMgmtServiceImpl implements IEmployeeMgmtService {
	@Autowired
	private IEmployeeRepository empRepo;

	@Override
	public String registerEmployee(Employee emp) {
		int idVal=empRepo.save(emp).getEid();
		return "Employee obj is saved with id value ::"+idVal;
	}
	
	@Override
	public List<Employee> showAllEmployees() {
		return empRepo.findAll();
	}

}
