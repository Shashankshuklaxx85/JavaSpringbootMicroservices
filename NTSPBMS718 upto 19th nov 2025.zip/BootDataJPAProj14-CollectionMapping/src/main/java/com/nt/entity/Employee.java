package com.nt.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapKeyColumn;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name="EMPLOYEE_COLLECTIONS")
@Data
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
public class Employee implements  Serializable{
	@Id
	@SequenceGenerator(name="gen1",sequenceName = "EID_SEQ1",initialValue = 1,allocationSize = 1)
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
	private  Integer eid;
	@NonNull
	@Column(length = 20)
	private  String  ename;
	@NonNull
	@Column(length = 20)
	private  String  eaddrs;
	
	@ElementCollection
	@CollectionTable(name = "FRIENDS_INFO_TAB",joinColumns = @JoinColumn(name="EMP_ID",referencedColumnName = "EID"))
	@Column(name="FRIEND_NAME")
	@NonNull
	private  List<String> friends;
	
	@ElementCollection
	@CollectionTable(name = "PHONES_INFO_TAB",joinColumns = @JoinColumn(name="EMP_ID",referencedColumnName = "EID"))
	@Column(name="PHONE_NUMBER")
	@NonNull
	private   Set<Long>  phones;
	
	@ElementCollection
	@CollectionTable(name = "ID_DDETAILS_INFO_TAB",joinColumns = @JoinColumn(name="EMP_ID",referencedColumnName = "EID"))
	@MapKeyColumn(name="ID_TYPE")// for  holding key
	@Column(name="ID_VALUE")  // for holding value
	@NonNull
	private   Map<String,String>  idDetails;
}
