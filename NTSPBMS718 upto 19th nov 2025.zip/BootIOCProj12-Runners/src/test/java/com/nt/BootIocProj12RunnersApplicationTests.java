package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootIocProj12RunnersApplicationTests {

	@Test
	void contextLoads() {
	}

}
