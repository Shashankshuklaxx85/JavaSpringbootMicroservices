package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.repository.IDepartmentRepository;
import com.nt.repository.IEmployeeRepository;


@Service("deptService")
public class DeparmentMgmtServiceImpl implements IDepartmentMgmtService {
     @Autowired
	private   IDepartmentRepository  deptRepo;
     @Autowired
	private  IEmployeeRepository   empRepo;

	@Override
	public List<Object[]> fetchDeptAndEmpsData() {
		return deptRepo.showDepartmentAndEmployeesData();
	}
	
	public List<Object[]> fetchEmpsAndDeptData(){
		return  empRepo.showEmpsAndDepartmentData();
	}
		

}
