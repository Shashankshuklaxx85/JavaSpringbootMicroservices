package com.nt.service;

import java.util.List;

import com.nt.entity.Department;
import com.nt.entity.Employee;

public interface IDepartmentMgmtService {
   
	public  List<Object[]>  fetchDeptAndEmpsData();
	public List<Object[]> fetchEmpsAndDeptData();
	
  }
