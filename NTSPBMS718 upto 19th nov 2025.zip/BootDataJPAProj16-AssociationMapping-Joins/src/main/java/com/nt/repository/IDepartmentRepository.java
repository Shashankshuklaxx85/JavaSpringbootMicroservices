package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.Department;

public interface IDepartmentRepository extends JpaRepository<Department, Integer> {

	//@Query("select d.did,d.name,d.location,e.eid,e.ename,e.salary,e.desg from Department d inner join d.emps e")
	//@Query("select d.did,d.name,d.location,e.eid,e.ename,e.salary,e.desg from Department d left join d.emps e")
	//@Query("select d.did,d.name,d.location,e.eid,e.ename,e.salary,e.desg from Department d right join d.emps e")
	@Query("select d.did,d.name,d.location,e.eid,e.ename,e.salary,e.desg from Department d full join d.emps e")
	public  List<Object[]> showDepartmentAndEmployeesData();
}
