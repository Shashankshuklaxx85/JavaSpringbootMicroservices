package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.Employee;

public interface IEmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("select e.eid,e.ename,e.salary,e.desg,d.did,d.name,d.location from Employee e inner join e.dept d")
	public  List<Object[]>  showEmpsAndDepartmentData();
}
