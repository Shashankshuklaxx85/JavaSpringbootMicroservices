//OneToManyAssociationTestRunner.java
package com.nt.runners;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Department;
import com.nt.entity.Employee;
import com.nt.service.DeparmentMgmtServiceImpl;
import com.nt.service.IDepartmentMgmtService;

@Component
public class OneToManyAssociationTestRunner implements CommandLineRunner {

	@Autowired
   private   IDepartmentMgmtService  service;


	@Override
	public void run(String... args) throws Exception {
	
		/*	try {
				List<Object[]> list=service.fetchDeptAndEmpsData();
				list.forEach(row->{
					System.out.println(Arrays.toString(row));
				});
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		try {
			List<Object[]> list=service.fetchEmpsAndDeptData();
			list.forEach(row->{
				System.out.println(Arrays.toString(row));
			});
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}//main
}//class
