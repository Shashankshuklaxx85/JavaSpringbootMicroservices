package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootIocProj07VersioningTimeStampingMetaDataAppTests {

	@Test
	void contextLoads() {
	}

}
