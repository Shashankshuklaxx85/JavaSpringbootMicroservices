package com.nt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.BankAccount;

import jakarta.transaction.Transactional;

public interface IBankAccountRepository extends JpaRepository<BankAccount, Long> {


}
