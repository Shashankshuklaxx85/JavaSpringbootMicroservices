package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj06InMemoryDBApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj06InMemoryDBApplication.class, args);
	}

}
