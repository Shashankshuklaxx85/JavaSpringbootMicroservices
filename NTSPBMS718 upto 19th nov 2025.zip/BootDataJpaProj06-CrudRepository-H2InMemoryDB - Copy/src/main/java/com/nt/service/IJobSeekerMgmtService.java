package com.nt.service;

import java.util.Optional;

import com.nt.entity.JobSeeker;

public interface IJobSeekerMgmtService {
    public  String registerJobSeekerGroup(Iterable<JobSeeker> list);
    public  long  showJobSeekersCount();
    public   Iterable<JobSeeker>  showAllJobSeekers();
    
}
