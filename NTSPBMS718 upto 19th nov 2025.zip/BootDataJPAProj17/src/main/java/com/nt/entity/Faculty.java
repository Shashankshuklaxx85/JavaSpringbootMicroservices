package com.nt.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="MTM_FACULTY")
@Setter
@Getter
@RequiredArgsConstructor
@NoArgsConstructor
public class Faculty {
    @Id
    @SequenceGenerator(name="gen1",sequenceName = "FID_SEQ",initialValue = 1,allocationSize=1)
    @GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
    private Integer fid;
    @NonNull
    @Column(length = 30)
    private  String  fname;

    @Column(length = 30)
    @NonNull
    private String addrs;

    @NonNull
    private Double income;

    @ManyToMany(targetEntity = Student.class,fetch = FetchType.EAGER,cascade=CascadeType.ALL)
    @JoinTable(name="MTM_FACULTIES_STUDENTS",
               joinColumns = @JoinColumn(name="faculty_id",referencedColumnName="fid"),
               inverseJoinColumns = @JoinColumn(name="student_id",referencedColumnName="sid"))
    private Set<Student> studs=new HashSet<>();

    @Override
    public String toString() {
        return "Faculty{" +
                "fid=" + fid +
                ", fname='" + fname + '\'' +
                ", addrs='" + addrs + '\'' +
                ", income=" + income +
                '}';
    }
}
