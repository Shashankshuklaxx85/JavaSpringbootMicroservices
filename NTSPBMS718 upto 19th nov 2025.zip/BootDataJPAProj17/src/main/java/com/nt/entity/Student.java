package com.nt.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="MTM_STUDENT")
@Setter
@Getter
@NoArgsConstructor
@RequiredArgsConstructor
public class Student {
    @Id
    @SequenceGenerator(name="gen1",sequenceName = "STUD_ID",allocationSize=1,initialValue = 1000)
    @GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
    private Integer sid;

    @Column(length = 30)
    @NonNull
    private String sname;

    @Column(length = 30)
    @NonNull
    private String addrs;

    @ManyToMany(targetEntity =  Faculty.class,cascade = CascadeType.ALL, fetch = FetchType.EAGER,mappedBy = "studs")
    private Set<Faculty> faculties = new HashSet<>();

    @Override
    public String toString() {
        return "Student{" +
                "addrs='" + addrs + '\'' +
                ", sname='" + sname + '\'' +
                ", sid=" + sid +
                '}';
    }
}
