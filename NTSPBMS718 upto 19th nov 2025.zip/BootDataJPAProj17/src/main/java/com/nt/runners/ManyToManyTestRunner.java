package com.nt.runners;

import com.nt.entity.Faculty;
import com.nt.entity.Student;
import com.nt.repository.IStudentRepository;
import com.nt.service.ICollegeMgmtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

@Component
public class ManyToManyTestRunner implements CommandLineRunner {
    @Autowired
    private ICollegeMgmtService collegeMgmtService;

    @Override
    public void run(String... args) throws Exception {
        /*try{
            //create Parent objects
            Faculty faculty1 = new Faculty("raja","hyd",90000.0);
            Faculty faculty2 = new Faculty("rajesh","hyd",80000.0);
            //create  Child objects
            Student  stud1=new Student("suresh","hyd");
            Student  stud2=new Student("ramesh","vizag");
            //add students to faculty
            faculty1.getStuds().add(stud1);
            faculty1.getStuds().add(stud2);
            faculty2.getStuds().add(stud1);
            //add faculties to studnets
            stud1.getFaculties().add(faculty1);
            stud1.getFaculties().add(faculty2);
            stud2.getFaculties().add(faculty2);

            //prepare Faculties List
            List<Faculty> faculties = Arrays.asList(faculty1,faculty2);
            //invoke the b.method

                String msg=collegeMgmtService.registerFacultyAndStudents(faculties);
                System.out.println(msg);
            } catch (Exception e) {
                e.printStackTrace();
            }
*/
/*
        try{
            //create Parent objects
            Faculty faculty1 = new Faculty("raja1","hyd",90000.0);
            Faculty faculty2 = new Faculty("rajesh1","hyd",80000.0);
            //create  Child objects
            Student  stud1=new Student("suresh1","hyd");
            Student  stud2=new Student("ramesh1","vizag");
            //add students to faculty
            faculty1.getStuds().add(stud1);
            faculty1.getStuds().add(stud2);
            faculty2.getStuds().add(stud1);
            //add faculties to studnets
            stud1.getFaculties().add(faculty1);
            stud1.getFaculties().add(faculty2);
            stud2.getFaculties().add(faculty2);

            //prepare Faculties List
            List<Student> studs = Arrays.asList(stud1,stud2);
            //invoke the b.method
            String msg=collegeMgmtService.registerStudentsAndFaculties(studs);
            System.out.println(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
*/
        /*try{
            collegeMgmtService.getFaculties().forEach(faculty -> {
                System.out.println("Faculty::"+faculty);
                Set<Student> studs=faculty.getStuds();
                studs.forEach(stud -> {
                    System.out.println("Student::"+stud);
                });
                System.out.println("=======================");
            });
        } catch (Exception e) {
            e.printStackTrace();
        }*/

        try{
            collegeMgmtService.getStudents().forEach(stud -> {
                System.out.println("student ::"+stud);
                Set<Faculty>  faculties = stud.getFaculties();
                for(Faculty faculty : faculties){
                    System.out.println("faculty ::"+faculty);
                }
                System.out.println("========================");

            });
        } catch (Exception e) {
            e.printStackTrace();
        }


        }//main

    }//class


