package com.nt.repository;

import com.nt.entity.Faculty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface IFacultyRepository extends JpaRepository<Faculty, Integer>
{

}
