package com.nt.service;

import com.nt.entity.Faculty;
import com.nt.entity.Student;
import com.nt.repository.IFacultyRepository;
import com.nt.repository.IStudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CollegeMgmtServiceImpl implements ICollegeMgmtService {
    @Autowired
    private IFacultyRepository facultyRepo;
    @Autowired
    private  IStudentRepository  studentRepo;

    @Override
    public String registerFacultyAndStudents(List<Faculty> faculties) {
        List<Faculty> savedFacultyList = facultyRepo.saveAll(faculties);
        return savedFacultyList.size()+" no.of faculties and their associated Students are saved";
    }

    @Override
    public String registerStudentsAndFaculties(List<Student> students) {
        List<Student> savedStudentList = studentRepo.saveAll(students);
        return savedStudentList.size()+" no.of Students and their associated Faculties are saved";
    }

    @Override
    public List<Faculty> getFaculties() {
        return facultyRepo.findAll();
    }

    @Override
    public List<Student> getStudents() {
        return studentRepo.findAll();
    }
}
