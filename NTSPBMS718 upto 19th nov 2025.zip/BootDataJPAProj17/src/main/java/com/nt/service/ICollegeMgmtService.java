package com.nt.service;

import com.nt.entity.Faculty;
import com.nt.entity.Student;

import java.util.List;

public interface ICollegeMgmtService {
    public String  registerFacultyAndStudents(List<Faculty> faculties);
    public String  registerStudentsAndFaculties(List<Student> students);
    public   List<Faculty> getFaculties();
    public List<Student> getStudents();

}
