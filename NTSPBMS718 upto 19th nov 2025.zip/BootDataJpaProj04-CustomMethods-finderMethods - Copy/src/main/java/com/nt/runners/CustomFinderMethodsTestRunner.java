package com.nt.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.nt.BootDataJpaProj04CustomFinderMethods;
import com.nt.entity.JobSeeker;
import com.nt.repository.IJobSeekerRepository;

@Component
public class CustomFinderMethodsTestRunner implements CommandLineRunner {

    private final BootDataJpaProj04CustomFinderMethods bootDataJpaProj04CustomFinderMethods;
	@Autowired
	private  IJobSeekerRepository  jsRepo;


    CustomFinderMethodsTestRunner(BootDataJpaProj04CustomFinderMethods bootDataJpaProj04CustomFinderMethods) {
        this.bootDataJpaProj04CustomFinderMethods = bootDataJpaProj04CustomFinderMethods;
    }
	
	
	@Override
	public void run(String... args) throws Exception {
		/*	try {   
			   //List<JobSeeker>  list=jsRepo.findByJsaddrsEquals("hyd");
				//List<JobSeeker>  list=jsRepo.readByJsaddrsIs("hyd");
				List<JobSeeker>  list=jsRepo.getByJsaddrs("hyd");
			   list.forEach(System.out::println);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		/*try {
			jsRepo.findByExpectedSalaryBetween(10000.0, 200000.0).forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*	try {
			   jsRepo.findByExpectedSalaryGreaterThanEqualAndExpectedSalaryLessThanEqual(10000.0, 100000.0).forEach(System.out::println);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		*/
		/*try {
			jsRepo.findByJsaddrsInOrderByJsaddrsDesc(List.of("hyd","vizag","delhi")).forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
	
		/*  	try {
				jsRepo.findByJsnameStartingWith("s").forEach(System.out::println);
				System.out.println("-----------------------------------");
				jsRepo.findByJsnameEndingWith("h").forEach(System.out::println);
				System.out.println("-----------------------------------");
				jsRepo.findByJsnameContaining("e").forEach(System.out::println);
				
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		/*	try {
				jsRepo.findByJsnameEqualsIgnoreCase("Mahesh").forEach(System.out::println);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		/*try {
			jsRepo.findByJsaddrsLikeAndQlfyIn("h%",List.of("BE","MCA")).forEach(System.out::println);
		}
		catch(Exception e) {
		   e.printStackTrace();	
		}*/
		try {
			jsRepo.findByJsaddrsNotInOrQlfyNotLike(List.of("hyd","vizag"), "B%").forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		   
		
	}//main

}//class
